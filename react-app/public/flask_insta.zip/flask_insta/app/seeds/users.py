from werkzeug.security import generate_password_hash
from app.models import db, User

# Adds a demo user, you can add other users here if you want


def seed_users():

    demo1 = User(username='demo',
                 email='demo@demo.com',
                 first_name='demo',
                 last_name='demo',
                 password='password')
    demo2 = User(username='demo_2',
                 email='demo_2@demo.com',
                 first_name='demo_2',
                 last_name='demo_2',
                 password='password')
    demo3 = User(username='demo_3',
                 email='demo_3@demo.com',
                 first_name='demo_3',
                 last_name='demo_3',
                 password='password')
    demo_leader = User(username="demo_leader",
                       email="demo_leader@demo.com",
                       first_name="demo_leader",
                       last_name="demo_leader",
                       password="password",
                       followers=[demo1, demo2, demo3])

    db.session.add_all([demo1, demo2, demo3, demo_leader])

    db.session.commit()

    print("---FOLLOWERS---", demo_leader.followers)
    print("---FOLLOWING---", demo_leader.followers[0].following)
    print("---CMNTLIKES___", demo_leader.comment_likes)
# Uses a raw SQL query to TRUNCATE the users table.
# SQLAlchemy doesn't have a built in function to do this
# TRUNCATE Removes all the data from the table, and resets
# the auto incrementing primary key


def undo_users():
    db.session.execute('TRUNCATE users RESTART IDENTITY CASCADE;')
    db.session.commit()
    print('users unseeded')
