from app.models import db, Comment, User


def seed_comments():
    comment1 = Comment(user_id=1,
                       post_id=1,
                       content="comment1")

    comment2 = Comment(user_id=3,
                       post_id=1,
                       content="comment2")

    comment3 = Comment(user_id=4,
                       post_id=2,
                       content="comment3")

    liker = User(username="liker",
                 email="liker@demo.com",
                 first_name="liker",
                 last_name="liker",
                 password="password",
                 comment_likes=[comment1, comment2, comment3])
    db.session.add_all([comment1, comment2, comment3, liker])
    db.session.commit()

    print('---COMMENTS---', comment1.to_dict())
    print('---COMMENTS---', comment2.to_dict())
    print('---COMMENTS---', comment3.to_dict())
    print('---LIKED_BY---', comment1.liked_by)


def undo_comments():
    db.session.execute('TRUNCATE comments RESTART IDENTITY CASCADE')
    db.session.commit()
    print('comments unseeded')
