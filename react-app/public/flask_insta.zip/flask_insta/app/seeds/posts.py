from app.models import db, Post, User


def seed_posts():
    post1 = Post(user_id=1,
                 caption="What a fun trip",
                 img_url="https://tinyurl.com/doggie901"
                 )

    post2 = Post(user_id=2,
                 caption="What a cute dog",
                 img_url="https://tinyurl.com/doggie901"
                 )
    post_liker = User(username="post_liker",
                      email="p_liker@demo.com",
                      first_name="post_liker",
                      last_name="post_liker",
                      password='password',
                      post_likes=[post1, post2])

    db.session.add_all([post1, post2, post_liker])
    db.session.commit()

    print('---POSTS---', post1.to_dict())
    print('---POSTS---', post2.to_dict())
    print('---LIKED---', post_liker.post_likes)


def undo_posts():
    db.session.execute('TRUNCATE posts RESTART IDENTITY CASCADE')
    db.session.commit()
    print('posts unseeded')
