from app.models import db, Message


def seed_msgs():
    message1 = Message(content="message1",
                       sender_id=1,
                       recipient_id=2
                       )

    message2 = Message(content="message2",
                       sender_id=2,
                       recipient_id=3
                       )
    message3 = Message(content="message3",
                       sender_id=3,
                       recipient_id=4
                       )

    db.session.add_all([message1, message2, message3])
    db.session.commit()
    print('---MESSAGES---', message1.to_dict())
    print('---MESSAGES---', message2.to_dict())
    print('---MESSAGES---', message3.to_dict())


def undo_msgs():
    db.session.execute('TRUNCATE messages RESTART IDENTITY CASCADE')
    db.session.commit()
    print('messages unseeded')
