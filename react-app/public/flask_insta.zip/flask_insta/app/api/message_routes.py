from flask import Blueprint, jsonify, request
from flask_login import login_required
from app.models import db, User, Message
from app.forms import PostMessage
from .auth_routes import validation_errors_to_error_messages


message_routes = Blueprint('messages', __name__)


@message_routes.route('/new', methods=["POST"])
@login_required
def get_messages():
    form = PostMessage()
    sender = form.data['sender_id']
    recipient = form.data['recipient_id']
    content = form.data['content']
    if form.validate_on_submit():
        msg = Message(
            sender_id=sender,
            recipient_id=recipient,
            content=content
        )
        db.session.add(msg)
        db.session.commit()
        return msg.to_dict()
    return {'errors': validation_errors_to_error_messages(form.errors)}
