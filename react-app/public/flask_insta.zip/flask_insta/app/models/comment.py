from .post import Post
from .db import db
from .user import User


class Comment(db.Model):
    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(1000), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    post_id = db.Column(db.Integer, db.ForeignKey('posts.id'))

    # liked_by = db.relationship("User",
    #                            secondary='c_likes',
    #                            backref="comment_likes")

    # liked_by = db.relationship("User",
    #                            lambda: comment_likes,
    #                            primaryjoin=lambda: Comment.id == (
    #                                comment_likes.c.comment_id),
    #                            secondaryjoin=lambda: User.id == (
    #                                comment_likes.c.user_id),
    #                            backref='likes')

    def to_dict(self):
        return {'id': self.id,
                'content': self.content,
                'user_id': self.user_id,
                'post_id': self.post_id,
                'liked_by': [user.to_dict() for user in self.liked_by]
                }
