from .db import db
from .user import User


class Post(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    caption = db.Column(db.String(1000), nullable=False)
    img_url = db.Column(db.String(255), nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "caption": self.caption,
            "img_url": self.img_url
        }

    def to_dict_likes(self):
        if self.liked_by:
            return {
                "id": self.id,
                "user_id": self.user_id,
                "caption": self.caption,
                "img_url": self.img_url,
                "liked_by": [user.to_dict() for user in self.liked_by]
            }
        else:
            print("TO_DICT_LIKES FAILURE, NO LIKES")
