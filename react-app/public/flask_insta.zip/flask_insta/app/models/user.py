from .db import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin


followers = db.Table(
    "followers",  # tablename
    db.Model.metadata,  # inheritance
    db.Column('leader_id', db.Integer, db.ForeignKey(
        "users.id"), primary_key=True),  # leader
    db.Column('follower_id', db.Integer, db.ForeignKey(
        "users.id"), primary_key=True),  # follower
)


# class Followers(db.Model):
#     __tablename__ = "followers"

#     leader_id = db.Column(db.Integer, db.ForeignKey(
#         "users.id"), primary_key=True)
#     follower_id = db.Column(
#         db.Integer, db.ForeignKey("users.id"), primary_key=True)
#     color = db.Column(db.String(255))

#     @property
#     def color_(self):
#         return self.color

#     @color_.setter
#     def set_color_(self, color):
#         self.color = color

#     def get_color(self):
#         return {
#             "color": self.color,
#             "leader_id": self.leader_id
#         }


c_likes = db.Table(
    'comment_likes',
    db.Model.metadata,
    db.Column('user_id',
              db.Integer,
              db.ForeignKey('users.id'),
              primary_key=True),
    db.Column('comment_id',
              db.Integer,
              db.ForeignKey('comments.id'),
              primary_key=True)
)

p_likes = db.Table(
    'post_likes',  # tablename
    db.Model.metadata,  # inherits
    db.Column('user_id',
              db.Integer,
              db.ForeignKey('users.id'),
              primary_key=True),
    db.Column('post_id',
              db.Integer,
              db.ForeignKey('posts.id'),
              primary_key=True)
)


class User(db.Model, UserMixin):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), nullable=False, unique=True)
    email = db.Column(db.String(255), nullable=False, unique=True)
    first_name = db.Column(db.String(255), nullable=True, unique=False)
    last_name = db.Column(db.String(255), nullable=True, unique=False)
    hashed_password = db.Column(db.String(255), nullable=False)

    post_likes = db.relationship("Post",
                                 secondary=p_likes,
                                 backref="liked_by")

    comment_likes = db.relationship("Comment",
                                    secondary=c_likes,
                                    backref="liked_by")

    following = db.relationship(
        'User', secondary="followers",
        primaryjoin=id == followers.c.follower_id,
        secondaryjoin=id == followers.c.leader_id,
        backref="followers"
    )

    # following = db.relationship(
    #     'User', secondary='followers',
    #     primaryjoin=id == Followers.follower_id,
    #     secondaryjoin=id == Followers.leader_id,
    #     backref="followers"
    # )

    @property
    def password(self):
        return self.hashed_password

    @password.setter
    def password(self, password):
        self.hashed_password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "first_name": self.first_name,
            "last_name": self.last_name,
        }

    def to_dict_full(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "followers": [follower.to_dict() for follower in self.followers],
            "following": [leader.to_dict() for leader in self.following],
            "post_likes": [post.to_dict() for post in self.post_likes],
            "comment_likes": [comment.to_dict() for comment in self.comment_likes]
        }
