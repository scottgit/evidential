from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField
from wtforms.validators import DataRequired
from app.models import Comment


class CommentForm(FlaskForm):
    user_id = IntegerField('user_id', validators=[DataRequired()])
    content = StringField('content', validators=[DataRequired()])


class CommentLikeForm(FlaskForm):
    user_id = IntegerField('user_id', validators=[DataRequired()])
