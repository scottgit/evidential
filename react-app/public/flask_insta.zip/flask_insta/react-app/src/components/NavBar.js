import React from 'react';
import {makeStyles} from "@material-ui/core/styles";
import {
  AppBar, 
  Typography, 
  Box, 
  IconButton, 
  Button, 
  MenuItem, 
  Menu, 
  Breadcrumbs, 
  InputBase
} from "@material-ui/core";
import MailIcon from "@material-ui/icons/Mail";
import NotificationsIcon from "@material-ui/icons/Notifications";

const useStyles = makeStyles((theme) => {
  // TODO : Create navbar styles
});


const NavBar = ({setAuthenticated}) => {
  return (
    <AppBar position="static">
      <IconButton edge="start" aria-label="menu">
        <MenuItem />
      </IconButton>
      <Typography variant="h6">
        Flaskagram
      </Typography>
      <Button color="inherit">Login</Button>
    </AppBar> 
  )
}


export default NavBar